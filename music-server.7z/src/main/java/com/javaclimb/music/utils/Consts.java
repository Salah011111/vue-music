package com.javaclimb.music.utils;

/**
 * 常量
 */
public class Consts {
    /*登录名*/
    public static final String NAME = "name";
    /*返回码*/
    public static final String CODE = "code";
    /*返回信息*/
    public static final String MSG = "msg";

}
