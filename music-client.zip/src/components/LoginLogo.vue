<template>
<div class="login-logo">
    <svg class="icon">
        <use xlink:href="#icon-erji"></use>
    </svg>
</div>
</template>
<script>
export default {
    name: 'login-logo'
}
</script>

<style lang="scss" scoped>
@import '../assets/css/login-logo.scss';
</style>